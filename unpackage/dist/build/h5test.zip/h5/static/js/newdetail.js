let newstailArray=[
	{
		id:"news1",
		title:"news1--title",
		content:"news1--contentnews1--contentnews1--contentnews1--contentnews1--content",
		time:"2020-6-3",
		source:"教育部",
		label:['高考','安排']
	},
	{
		id:"news2",
		title:"news2--title",
		content:"news2--content",
		time:"2020-6-3",
		source:"教育部",
		label:['山东','延迟']
	},
	{
		id:"news3",
		title:"news3--title",
		content:"news3--content",
		time:"2020-6-3",
		source:"教育部",
		label:['新高考','安排']
	},
]

export default newstailArray