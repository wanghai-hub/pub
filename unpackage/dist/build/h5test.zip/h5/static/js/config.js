//var baseUrl = 'http://localhost:7788';
var baseUrl = 'http://172.31.2.61:8091';
var proUrl = 'http://edu.grpcloud.cn';

export default{
	getProUrl:function(){
		return baseUrl;
	}
}